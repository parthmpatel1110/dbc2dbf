#!/usr/bin/env python3
import sys
sys.path.append('..')

import canmatrix.cli.compare
canmatrix.cli.compare.cli_compare()
