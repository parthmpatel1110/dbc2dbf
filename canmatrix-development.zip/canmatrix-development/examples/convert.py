#!/usr/bin/env python3
import sys
sys.path.append('..')

import canmatrix.cli.convert
canmatrix.cli.convert.cli_convert()
