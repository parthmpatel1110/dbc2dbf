#!/bin/sh

cd test
python ./test.py
